package com.taller.seccion1;

public class Ejercicios8 {

	public static void main(String[] args) {
String textto = "maiz";
// esto causara un error al intentar convertir a numero 


try {
	int numero = Integer.parseInt(textto);
	System.out.println( " el numero es: "  + numero );
} 
catch  (NumberFormatException e ) { 
System.out.println("ERROR: ' " + textto + "' no es un numero valido");
//esta es la exepcion 
}
	}

}
