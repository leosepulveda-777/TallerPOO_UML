package com.taller.seccion1;

public class Ejercicios11 {

	public static void main(String[] args) {
		
		double  aleatorioRandom = Math.random();
		//esto selecciona un double aleatorio, desde 0.0 hasta infinito
		System.out.println( " EL NUMERO RANDOM ES:" + aleatorioRandom);
		
	}

}
