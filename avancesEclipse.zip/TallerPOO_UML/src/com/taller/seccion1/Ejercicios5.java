package com.taller.seccion1;

public class Ejercicios5 {

	public static void main(String[] args) {
		// era comentar lineas en los codigos 
	}

}
