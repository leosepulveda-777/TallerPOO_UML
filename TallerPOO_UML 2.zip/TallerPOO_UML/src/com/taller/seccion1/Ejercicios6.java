package com.taller.seccion1;

import java.util.Scanner; 

public class Ejercicios6 {


 //importamos la clase , para leer datos del usuario
 	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Ingrese la edad ");
		int edad = sc.nextInt();
		//pedimos al usuario que ingrese su edad 
		
		System.out.println( " Ingrese su estatura "  );
		double altura = sc.nextDouble();
		//pedimos al usuario que ingrese su estatura
	
		
	
	
 	  }
}
		 
	


