package com.taller.seccion1;

public class Ejercicios14 {

	public static void main(String[] args) {
	 
		String text1 = "";
		String text2 = "Hola profe!";
		//ponemos una variable vacia tipo string , para que detecte el error 
		
		
		System.out.println ( " ¿El texto1 esta vacio? " + text1.isEmpty());
		//como este esta vacio , nos arrojara un true 
		System.out.println ( " ¿El texto2 esta vacio? " + text2.isEmpty());
		//como este tiene texto por dentro , arroja un false 
		
		
		
		
		
		
		
		
		
	}

}
