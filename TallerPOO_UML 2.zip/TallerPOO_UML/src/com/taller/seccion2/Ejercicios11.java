package com.taller.seccion2;

import java.util.ArrayList;
import java.util.Arrays;

public class Ejercicios11 {

	public static void main(String[] args) {
	
 ArrayList<Integer> numeros = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6 ));
 //la lista

	        for (int n : numeros) {
	            if (n % 2 == 0){
	            	//el modulo que nos ayuda a saber si es par o no 
	                System.out.println(n);
	                //aca imprimos el numero
	            }
	        }
		
		
	
	}

}
