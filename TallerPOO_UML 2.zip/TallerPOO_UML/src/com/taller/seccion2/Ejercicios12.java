package com.taller.seccion2;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
public class Ejercicios12 {

	public static void main(String[] args) {
		
	ArrayList<Integer> numeros = new ArrayList<>(Arrays.asList(2, 1, 4, 6, 7, 5 ));
	 //la lista
	
	System.out.println( " antes de ordena , estos son los numeros:  " + numeros );
		//imprimir los numeros antes de ordenar 
	
	Collections.sort(numeros);
	//ordenar lista
	
	System.out.println( " Despues de ordenar , estos son los numeros: " + numeros );
		
	}

}
