package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicios6 {

	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);	
	String correcta = "2285";
	String ingreso = "";
	//las variables que necesitamos y las definimos como string , porq es una palabra 
	do { 
		System.out.println(" ingrese la contraseña ");
		 ingreso = sc.nextLine();
		 // para que el usuario ingrese su clave 
		
	} while (ingreso == correcta);
	System.out.println(" Contraseña correcta! ");
	// aqui si la de ingreso coincide con la correcta , imprime ese mensaje
		
	}

}
