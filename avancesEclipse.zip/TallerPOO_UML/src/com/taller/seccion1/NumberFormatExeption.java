package com.taller.seccion1;

public class NumberFormatExeption extends Exception {

}
