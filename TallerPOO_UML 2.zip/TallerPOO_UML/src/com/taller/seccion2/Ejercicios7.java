package com.taller.seccion2;

public class Ejercicios7 {

	public static void main(String[] args) {
		
	for (int  i = 1; i<=10;i++){
		if (i==3) {
			System.out .println(" Me salto el numero 3");
			continue;
			
		}
			
		if (i==7) {
			System.out.println( " numero 7 encontrado , se sale de ahi " );
			break;
		}
		System.out.println("numero: " + i);
		}
	}
		
		
		
		
	}

