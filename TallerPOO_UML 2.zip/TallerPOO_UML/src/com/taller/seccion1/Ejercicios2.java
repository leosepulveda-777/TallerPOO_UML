package com.taller.seccion1;

public class Ejercicios2 {

	public static void main(String[] args) {
		int edad = 15;
		double estatura = 1.75;
		char inicial = 'L';
		String nombre = "Lucas";
		boolean esHombre = true;
		// teniendo las variables , podemos pasar al siguiente paso
		
		System.out.println(" Edad " + edad);
		System.out.println(" La estatura es " + estatura);
		System.out.println( " La inicial es " + inicial);
		System.out.println( " El nombre es " + nombre);
		System.out.println( " ¿Es hombre? " + esHombre);
		//imprimimos lo anteriormente mencionado 

		
		
		
		
	}
}