package com.taller.seccion3;

public class Ejercicios1 {

	public static void main(String[] args) {
		
		int [] numeros = new int[5];	
		
	

	}

}
