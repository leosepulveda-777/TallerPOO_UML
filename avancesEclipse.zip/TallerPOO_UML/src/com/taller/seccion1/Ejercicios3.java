package com.taller.seccion1;

public class Ejercicios3 {

	public static void main(String[] args) {
		int a = 23;
		int b = 22;
		//definimos variables , en este caso tipo entero ,porque utilizamos numeros enteros
		
		System.out.println(" La suma es " + (a+b));
		System.out.println(" La resta es " + (a-b));
		System.out.println(" La multiplicacion  es " + (a*b));
		System.out.println(" La suma es " + (a+b));
		System.out.println(" La division es " + (a/b));
		System.out.println(" El modulo es " + (a%b));
		//imprimos lo que el profesor nos solicito, en este caso +,-,*,/,%
	}

}
