package com.taller.seccion1;

public class Ejercicios4 {

	public static void main(String[] args) {
	int edad  = 19;
	double altura = 1.74;
	//definimos las variables que necesitamos 
	
	
	//operadores relacionales
	System.out.println(" ¿Es mayor de 18? " + (edad>18));
	System.out.println(" Estatura menor o igual a 1.80 " +(altura<=1.80));
	System.out.println( " ¿Edad igual a 19? " + (edad==19));
	System.out.println ( "¿Altura diferente de 1.60?" +  (altura != 1.60) );
	//imprimimos lo que quiera que aprezca, mas el + para que tome en cuenta la variable y el texto
	
	
	//operadores logicos
	System.out.println( "¿ Edad > 17 y estatura > 1.60? " + (edad > 17 && altura > 1.60) );
	System.out.println( "Edad < 18 o estatura > 1.86 " + (edad < 18 || altura > 1.86));
	//imprimimos lo que quiera que aprezca, mas el + para que tome en cuenta la variable y el texto
	
		
	} 

}
