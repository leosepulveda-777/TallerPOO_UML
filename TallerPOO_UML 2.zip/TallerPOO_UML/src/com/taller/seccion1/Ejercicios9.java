package com.taller.seccion1;

public class Ejercicios9 {
	public static void main(String[] args) {
	 final int EDAD_MINIMA = 18;
	 final double PI = 3.14159;
	 //defini constantes como final 
	 
	 System.out.println( "¿edad minima? " + EDAD_MINIMA );
	 System.out.println( " ¿Cual es el valor de pi? "  + PI);
	 //imprimi lo que queria expresar 
	
		
}
}