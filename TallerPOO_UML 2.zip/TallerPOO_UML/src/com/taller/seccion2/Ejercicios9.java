package com.taller.seccion2;

public class Ejercicios9 {

	public static void main(String[] args) {
		
	String[]nombres={"CR7","MESSI","JAMES RODRIGUEZ"};
	for (String nombre : nombres) {
		System.out.println(" Hola crack " + nombre + "!");
	}
	
		
		
	}

}
