package com.taller.seccion2;

public class Ejercicios4 {

	public static void main(String[] args) {
		
for (int  i = 1; i<=20; i++)	{
	int factorial = 1;
	//la variable del factorial 
	for (int j = 1; j<=i; j++) {
		factorial = factorial * j;
	}
	System.out.println(i + " ! = " + factorial );
	//unimos e imprimimos todo lo necesario
	}
	     
}
		
		
		
	}


