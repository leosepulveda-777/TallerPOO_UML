package com.taller.seccion3;

public class Ejercicios2 {

	public static void main(String[] args) {
	
		String[] frutas = {"Manzana" , "Banano" , "Pera" , "Uva" , "Mango"};
		
		
		
		
		
	}

}
