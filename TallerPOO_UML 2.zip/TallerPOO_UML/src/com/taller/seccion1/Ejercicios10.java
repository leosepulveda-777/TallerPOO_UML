package com.taller.seccion1;

public class Ejercicios10 {
	public static void main(String[] args) {
		
		double base = 4;
		double exponente = 3;
		double numero = 16;
		
		double potencia =  Math.pow(base, exponente);
		//utilizamos esta math , para calcular la potencia 
		double raiz = Math.sqrt(numero);
		// utilizamos esta math , para calcular la raiz
		System.out .println( base + " elevado a " + exponente + " es: " + potencia  );
		System.out.println(  "La raiz cuadrada de " + numero +  " es: "+ raiz );
		//imprimimos los resultados 
		
		
		
}
}