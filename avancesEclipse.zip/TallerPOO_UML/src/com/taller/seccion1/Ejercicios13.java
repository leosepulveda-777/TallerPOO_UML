package com.taller.seccion1;

public class Ejercicios13 {

	public static void main(String[] args) {
		
		
		char caracter = 'W';
		int codigoAscii = (int) caracter ;
		
		//es convertir el caraacter a un ascii , o sea un entero
		
		System.out.println( " El codigo de ASCII de '"  + caracter + "' es: " + codigoAscii); 
		//imprimimos lo que queremos
				

	}

}
