package com.taller.seccion3;

public class Ejercicios3 {

	public static void main(String[] args) {
		
		String[] frutas = {"Manzana" , "Banano" , "Pera" , "Uva" , "Mango"};
		
		System.out.println( " Recorrido con indice:  " );
		for (int i = 0; i < frutas.length; i++) {
			
			System.out.println(frutas[i]);
		}
		 
		System.out.println( " Recorrido con el for-each: ");
		for (String fruta : frutas ) {
			System.out.println(fruta);
	}

}
}