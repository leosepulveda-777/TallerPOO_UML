package com.taller.seccion2;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class Ejercicios13 {

	public static void main(String[] args) {
	ArrayList<Integer> numeros = new ArrayList<>(Arrays.asList(2, 3, 3, 4 , 7, 7 ));
	//la lista		
		
		System.out.println( " Lista original: " + numeros);
		//muestra la lista original 
		
	HashSet<Integer> sinDuplicados = new HashSet<>(numeros);
	System.out.println( " Lista sin duplicados: " + sinDuplicados);
	//imprime y muestra los valores de la lista sin repetir 

	}

}
