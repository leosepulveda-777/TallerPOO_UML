package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicios3 {
 
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		//para que el usuario pueda poner la opcion de preferencia
		
		System.out.println(" Menu ");
		System.out.println( " 1 saludar ");
		System.out.println(" 2 mostrar la hora " );
		System.out.println( "  3 salir...");
		System.out.println( "  Elige una opcion " );
		//menu 
		int opcion = sc.nextInt();
		switch (opcion) {
		
		
		case 1:
		System.out.println( " Hola " );
		break;
		
		case 2:
			System.out.println( " La hora es: 10:00 AM " );
			break;
			
		case 3:
			System.out.println( " Saliendo..." );
			break;
			
		default:
			System.out.println( " ELIGE UNA OPCION VALIDA " );
			//este funciona , para que el usuario ingrese una opcion que este dentro del menu
	}
	

}
}