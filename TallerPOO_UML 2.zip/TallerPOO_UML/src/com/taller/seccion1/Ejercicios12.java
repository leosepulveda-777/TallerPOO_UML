package com.taller.seccion1;

public class Ejercicios12 {

	public static void main(String[] args) {
		String nombre = "Juan";
		int edad = 17;
		double  promedio = 4.589;
		// definimos las variables 
		
		System.out.printf("Nombre: %s/n" , nombre);
		System.out.printf("Edad: %d " , edad );
		System .out.printf( "Promedio:,  %.2f/n" , promedio);
		System.out.printf( "Hola, soy %s, tengo %d y mi promedio es %.2f/n", nombre , edad , promedio);
		// practicamente el tf , es un ln , pero mas resumido , y mucho mas facil de entender 
	}


}
