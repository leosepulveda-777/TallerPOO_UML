package com.taller.seccion1;

public class Ejercicios7 {

	public static void main(String[] args) {
		// de string a int
		String  texto = "123";
		int numeroEntero = Integer.parseInt(texto);
		System.out.println( " String a int es  : " + numeroEntero);
		
		//string a double 
		double numeroDecimal = Double.parseDouble(texto);
		System.out.println( " String a double es : " + numeroDecimal );
		
		
		//int a string 
		int A = 245;
		String cadena = Integer.toString(A);
		System.out.println( " int a string es : " + cadena);
		
		
		//double a string 
		double B = 14.2;
		String cadenaDos = Double.toString(B);
		System.out.println( " double a string es :  " + cadenaDos );
		 
		
	}

}
