package com.taller.seccion2;
import java.util.Scanner;

public class Ejercicios5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int numero ;
		int suma = 0;
		//variables
		
		System.out.println( " Escriba eel numero para sumar y esccriba 0 para terminar" );
while (true) { 
// la condicion 
	System.out.print(" Numero: ");
	numero = sc.nextInt();
	if (numero==0) // la condicion 
	 {
	break;
	}
	suma = suma + numero; 
}
System.out.println( " la suma total es " + suma );
	
}
	}


