package com.taller.seccion2;

public class Ejercicios2 {

	public static void main(String[] args) {
		
	int edad = 85;
	//la variable
	
	if ( edad <13) {
	System.out.println( " Eres un niño ");
	//la primera condicion
	} else if (edad <18);{
	System.out.println( " Eres un adolescente "); }
	//imprime que eres adolescente
	
	
	 if (edad<60) {
	System.out.println( " Eres un adulto "); 
	//adulto y lo imprime
	
	} else {
		System.out.println( " Eres un anciano " );
		//sino eres adulto , eres un anciano
	}
		
}
		
	}

//lo que imprima, es la segunda opcion 
