package com.taller.seccion2;

class Ejercicios1 {

	public static void main(String[] args) {
		
		 int numero = 28;
		 //definimos el numero que queramos comprobra la condicion
		 
		if (numero %2 == 0) {
			System.out.println(" El numero es par  ");
		//imprimos en caso de que su residuo sea 0 , este es par
			
		} 
	
	else { 
			System.out.println(" El numero es impar" );
			// si su residuo no es 0 , entonces es impar
		
		}
		
		
	
		
	}

}
