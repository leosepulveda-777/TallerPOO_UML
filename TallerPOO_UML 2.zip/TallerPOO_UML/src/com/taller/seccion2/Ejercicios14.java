package com.taller.seccion2;
import java.util.ArrayList;
import java.util.List; 
import java.util.Arrays;

public class Ejercicios14 {

	public static void main(String[] args) {
	String [] frutas = {"Manzana" , "Banano" , "Pera" , "Uva"};
	//crear una array
	
	
	
	List<String> listaFrutas = Arrays.asList(frutas);
		//pasar de array a lista 
		

	
	System.out.println( " Lista de frutas: " );
	for (String fruta : listaFrutas) {
		System.out.println(fruta);
		
	}
	}

}
