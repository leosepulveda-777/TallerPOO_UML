package com.taller.seccion2;

public class Ejercicios10 {

public static void main(String[] args) {
	
	 for (int i = 0; i < 10; i++) {
         System.out.print(fibonacci(i) + " ");
     }
 }

 public static int fibonacci(int n){
	 //probamos el caso porque si n es 0 o 1 , retorna n (porque los dos primeros numeros son 0 y 1 )
     if (n <= 1) {
         return n;
     } else {
         return fibonacci(n - 1) + fibonacci(n - 2);
         //suma los dos numeros anteriores 
 }
 }
}

