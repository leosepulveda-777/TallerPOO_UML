package com.taller.seccion1;

public class Ejercicios1 {

	public static void main(String[] args) {
		int edad = 15;
		//defini la edad del usuario
		double estatura = 1.75;
		//igual que la estatura
		char inicial = 'L';
		//lo mismo con su inicial
		String nombre = "Lucas";
	//	y lo mismo con su nombre
		boolean esHombre = true;
		// aqui defini la variable de si era hombre , xq ps , el mundo esta muy cambiado 
	}

}
