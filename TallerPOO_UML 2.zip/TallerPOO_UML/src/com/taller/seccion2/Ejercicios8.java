package com.taller.seccion2;

public class Ejercicios8 {

	public static void main(String[] args) {
	
for (int i = 1; i<=10; i++) {
	System.out.println( "Tabla del "  + i + ":");
//primer bucle: del 1 al 10 (tabla).
	
	
for	(int l = 1; l<=10; l++) {
	
	System.out.println( i + "x" + l + "=" + (i*l));
	//segundo bucle: del 1 al 10 (multiplicadores).
	
}
		
	}

	}
}

